import { View } from "react-native";

export default function Separator(){
  return (
    <View className="w-full h-px my-4 bg-black opacity-10">
    </View>
  );
}